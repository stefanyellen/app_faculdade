import 'package:flutter/material.dart';

class CadastroScreen extends StatelessWidget {
  CadastroScreen({super.key});

  final TextEditingController userController = TextEditingController();
  final TextEditingController passController = TextEditingController();

  void cadastrar(BuildContext context) {
    Navigator.pop(context); // volta pro login
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Cadastro")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              "Cadastre-se",
              style: TextStyle(fontSize: 28),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: userController,
              decoration: const InputDecoration(labelText: "Usuário"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: passController,
              obscureText: true,
              decoration: const InputDecoration(labelText: "Senha"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => cadastrar(context),
              child: const Text("Cadastrar"),
            )
          ],
        ),
      ),
    );
  }
}
