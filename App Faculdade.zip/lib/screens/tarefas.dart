import 'package:flutter/material.dart';
import '../models/task.dart';

class TarefasScreen extends StatefulWidget {
  const TarefasScreen({super.key});

  @override
  State<TarefasScreen> createState() => _TarefasScreenState();
}

class _TarefasScreenState extends State<TarefasScreen> {
  List<Task> tarefas = [];

  void adicionarTarefa(String titulo) {
    setState(() {
      tarefas.add(Task(title: titulo));
      ordenarTarefas();
    });
  }

  void alternarTarefa(Task tarefa) {
    setState(() {
      tarefa.isDone = !tarefa.isDone;
      ordenarTarefas();
    });
  }

  void removerTarefa(Task tarefa) {
    setState(() {
      tarefas.remove(tarefa);
    });
  }

  void ordenarTarefas() {
    tarefas.sort((a, b) {
      if (a.isDone == b.isDone) {
        return a.title.compareTo(b.title);
      }
      return a.isDone ? 1 : -1;
    });
  }

  void mostrarDialogo() {
    TextEditingController controller = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Nova tarefa"),
        content: TextField(controller: controller),
        actions: [
          TextButton(
            onPressed: () {
              adicionarTarefa(controller.text);
              Navigator.pop(context);
            },
            child: const Text("Adicionar"),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Tarefas")),
      floatingActionButton: FloatingActionButton(
        onPressed: mostrarDialogo,
        child: const Icon(Icons.add),
      ),
      body: ListView(
        children: tarefas.map((tarefa) {
          return ListTile(
            title: Text(
              tarefa.title,
              style: TextStyle(
                decoration: tarefa.isDone ? TextDecoration.lineThrough : null,
              ),
            ),
            leading: Checkbox(
              value: tarefa.isDone,
              onChanged: (_) => alternarTarefa(tarefa),
            ),
            trailing: IconButton(
              icon: const Icon(Icons.delete),
              onPressed: () => removerTarefa(tarefa),
            ),
          );
        }).toList(),
      ),
    );
  }
}
